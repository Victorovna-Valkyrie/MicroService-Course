package com.zjsu.jyj.course.controller;

import com.zjsu.jyj.course.model.Enrollment;
import com.zjsu.jyj.course.service.EnrollmentService;
import com.zjsu.jyj.course.util.Result;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
public class EnrollmentController {
    @Autowired
    private EnrollmentService enrollmentService;

    @GetMapping
    public Result<List<Enrollment>> getAllEnrollments() {
        return Result.success(enrollmentService.getAllEnrollments());
    }

    @GetMapping("/{id}")
    public Result<Enrollment> getEnrollmentById(@PathVariable String id) {
        return Result.success(enrollmentService.getEnrollmentById(id));
    }

    @GetMapping("/course/{courseId}")
    public Result<List<Enrollment>> getByCourseId(@PathVariable String courseId) {
        return Result.success(enrollmentService.getEnrollmentsByCourseId(courseId));
    }

    @GetMapping("/student/{studentId}")
    public Result<List<Enrollment>> getByStudentId(@PathVariable String studentId) {
        return Result.success(enrollmentService.getEnrollmentsByStudentId(studentId));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Result<Enrollment> createEnrollment(@Valid @RequestBody Enrollment enrollment) {
        return Result.success(201, "选课成功", enrollmentService.createEnrollment(enrollment));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Result<Void> deleteEnrollment(@PathVariable String id) {
        enrollmentService.deleteEnrollment(id);
        return Result.success(204, "退课成功", null);
    }
}