package com.zjsu.jyj.course.model;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Instructor {
    @NotBlank(message = "教师ID不能为空")
    private String id;
    @NotBlank(message = "教师姓名不能为空")
    private String name;
    @NotBlank(message = "教师邮箱不能为空")
    private String email;
}