package com.zjsu.jyj.course.repository;

import com.zjsu.jyj.course.model.Course;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class CourseRepository {
    private final Map<String, Course> courseMap = new ConcurrentHashMap<>();

    public List<Course> findAll() {
        return new ArrayList<>(courseMap.values());
    }

    public Optional<Course> findById(String id) {
        return Optional.ofNullable(courseMap.get(id));
    }

    public Course save(Course course) {
        if (course.getId() == null) {
            course.setId(UUID.randomUUID().toString());
        }
        courseMap.put(course.getId(), course);
        return course;
    }

    public boolean deleteById(String id) {
        return courseMap.remove(id) != null;
    }
}