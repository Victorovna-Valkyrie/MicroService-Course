package com.zjsu.jyj.course.model;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Enrollment {
    private String id;
    @NotBlank(message = "课程ID不能为空")
    private String courseId;
    @NotBlank(message = "学生ID（学号）不能为空")
    private String studentId; // 此处为学号，后续会转为系统UUID
    private LocalDateTime createdAt;
}