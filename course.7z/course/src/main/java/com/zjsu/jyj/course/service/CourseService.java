package com.zjsu.jyj.course.service;

import com.zjsu.jyj.course.exception.ResourceNotFoundException;
import com.zjsu.jyj.course.model.Course;
import com.zjsu.jyj.course.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CourseService {
    @Autowired
    private CourseRepository courseRepository;

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }

    public Course getCourseById(String id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("课程不存在（ID：" + id + "）"));
    }

    public Course createCourse(Course course) {
        course.setEnrolled(0);
        return courseRepository.save(course);
    }

    public Course updateCourse(String id, Course course) {
        Course existing = getCourseById(id);
        existing.setCode(course.getCode());
        existing.setTitle(course.getTitle());
        existing.setInstructor(course.getInstructor());
        existing.setSchedule(course.getSchedule());
        existing.setCapacity(course.getCapacity());
        return courseRepository.save(existing);
    }

    public void deleteCourse(String id) {
        getCourseById(id);
        courseRepository.deleteById(id);
    }

    public void updateEnrolledCount(String courseId, int increment) {
        Course course = getCourseById(courseId);
        course.setEnrolled(Math.max(0, course.getEnrolled() + increment));
        courseRepository.save(course);
    }
}