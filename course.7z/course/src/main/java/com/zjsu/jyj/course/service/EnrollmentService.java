package com.zjsu.jyj.course.service;

import com.zjsu.jyj.course.exception.BusinessException;
import com.zjsu.jyj.course.exception.ResourceNotFoundException;
import com.zjsu.jyj.course.model.Course;
import com.zjsu.jyj.course.model.Enrollment;
import com.zjsu.jyj.course.model.Student;
import com.zjsu.jyj.course.repository.EnrollmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class EnrollmentService {
    @Autowired
    private EnrollmentRepository enrollmentRepository;
    @Autowired
    private CourseService courseService;
    @Autowired
    private StudentService studentService;

    public List<Enrollment> getAllEnrollments() {
        return enrollmentRepository.findAll();
    }

    public Enrollment getEnrollmentById(String id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("选课记录不存在（ID：" + id + "）"));
    }

    public List<Enrollment> getEnrollmentsByCourseId(String courseId) {
        courseService.getCourseById(courseId);
        return enrollmentRepository.findByCourseId(courseId);
    }

    public List<Enrollment> getEnrollmentsByStudentId(String studentId) {
        studentService.getStudentById(studentId);
        return enrollmentRepository.findByStudentId(studentId);
    }

    public Enrollment createEnrollment(Enrollment enrollment) {
        String courseId = enrollment.getCourseId();
        String studentId = enrollment.getStudentId(); // 学号

        // 验证学生并转为系统ID
        Student student = studentService.getStudentByStudentId(studentId);
        String systemStudentId = student.getId();

        // 验证课程
        Course course = courseService.getCourseById(courseId);

        // 检查重复选课
        if (enrollmentRepository.existsByCourseIdAndStudentId(courseId, systemStudentId)) {
            throw new BusinessException("重复选课：学生（" + studentId + "）已选课程（" + courseId + "）");
        }

        // 检查容量
        if (course.getEnrolled() >= course.getCapacity()) {
            throw new BusinessException("课程已满：容量" + course.getCapacity() + "，已选" + course.getEnrolled());
        }

        // 保存选课记录
        enrollment.setStudentId(systemStudentId);
        enrollment.setCreatedAt(LocalDateTime.now());
        Enrollment saved = enrollmentRepository.save(enrollment);

        // 更新课程人数
        courseService.updateEnrolledCount(courseId, 1);
        return saved;
    }

    public void deleteEnrollment(String id) {
        Enrollment enrollment = getEnrollmentById(id);
        enrollmentRepository.deleteById(id);
        courseService.updateEnrolledCount(enrollment.getCourseId(), -1);
    }
}