package com.zjsu.jyj.course;

import com.zjsu.jyj.course.model.Course;
import com.zjsu.jyj.course.model.Instructor;
import com.zjsu.jyj.course.model.ScheduleSlot;
import com.zjsu.jyj.course.model.Student;
import com.zjsu.jyj.course.service.CourseService;
import com.zjsu.jyj.course.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDateTime;

@SpringBootApplication
public class CourseApplication implements CommandLineRunner {
    @Autowired
    private CourseService courseService;
    @Autowired
    private StudentService studentService;

    public static void main(String[] args) {
        SpringApplication.run(CourseApplication.class, args);
        System.out.println("选课系统启动成功：http://localhost:8080/api/courses");
    }

    @Override
    public void run(String... args) {
        // 初始化测试数据
        Instructor instructor1 = new Instructor("T001", "张教授", "zhang@edu.cn");
        ScheduleSlot schedule1 = new ScheduleSlot("MONDAY", "08:00", "10:00", 50);
        courseService.createCourse(new Course(null, "CS101", "计算机导论", instructor1, schedule1, 60, 0));

        Student student1 = new Student(null, "2024001", "张三", "计算机", 2024, "zhangsan@edu.cn", LocalDateTime.now());
        studentService.createStudent(student1);
        System.out.println("测试数据初始化完成：课程CS101、学生2024001");
    }
}