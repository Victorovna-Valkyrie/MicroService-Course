package com.zjsu.jyj.course.repository;

import com.zjsu.jyj.course.model.Enrollment;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

@Repository
public class EnrollmentRepository {
    private final Map<String, Enrollment> enrollmentMap = new ConcurrentHashMap<>();

    public List<Enrollment> findAll() {
        return new ArrayList<>(enrollmentMap.values());
    }

    public Optional<Enrollment> findById(String id) {
        return Optional.ofNullable(enrollmentMap.get(id));
    }

    public List<Enrollment> findByCourseId(String courseId) {
        return enrollmentMap.values().stream()
                .filter(e -> courseId.equals(e.getCourseId()))
                .collect(Collectors.toList());
    }

    public List<Enrollment> findByStudentId(String studentId) {
        return enrollmentMap.values().stream()
                .filter(e -> studentId.equals(e.getStudentId()))
                .collect(Collectors.toList());
    }

    public boolean existsByCourseIdAndStudentId(String courseId, String studentId) {
        return enrollmentMap.values().stream()
                .anyMatch(e -> courseId.equals(e.getCourseId()) && studentId.equals(e.getStudentId()));
    }

    public Enrollment save(Enrollment enrollment) {
        if (enrollment.getId() == null) {
            enrollment.setId(UUID.randomUUID().toString());
        }
        enrollmentMap.put(enrollment.getId(), enrollment);
        return enrollment;
    }

    public boolean deleteById(String id) {
        return enrollmentMap.remove(id) != null;
    }
}