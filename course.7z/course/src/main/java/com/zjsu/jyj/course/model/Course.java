package com.zjsu.jyj.course.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Course {
    private String id;
    @NotBlank(message = "课程编码不能为空")
    private String code;
    @NotBlank(message = "课程名称不能为空")
    private String title;
    @Valid
    private Instructor instructor;
    @Valid
    private ScheduleSlot schedule;
    @Positive(message = "课程容量必须为正数")
    private Integer capacity;
    private Integer enrolled = 0;
}