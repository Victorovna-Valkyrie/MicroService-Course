package com.zjsu.jyj.course.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScheduleSlot {
    @NotBlank(message = "星期不能为空")
    private String dayOfWeek;
    @NotBlank(message = "开始时间不能为空")
    private String startTime;
    @NotBlank(message = "结束时间不能为空")
    private String endTime;
    @Positive(message = "预期出勤人数必须为正数")
    private Integer expectedAttendance;
}