package com.zjsu.jyj.course.controller;

import com.zjsu.jyj.course.model.Student;
import com.zjsu.jyj.course.service.StudentService;
import com.zjsu.jyj.course.util.Result;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    @Autowired
    private StudentService studentService;

    @GetMapping
    public Result<List<Student>> getAllStudents() {
        return Result.success(studentService.getAllStudents());
    }

    @GetMapping("/{id}")
    public Result<Student> getStudentById(@PathVariable String id) {
        return Result.success(studentService.getStudentById(id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Result<Student> createStudent(@Valid @RequestBody Student student) {
        return Result.success(201, "学生创建成功", studentService.createStudent(student));
    }
    @PutMapping("/{id}")
    public Result<Student> updateStudent(@PathVariable String id, @Valid @RequestBody Student student) {
        // 补充状态码参数（200 表示成功），匹配 Result.success 的三个参数重载方法
        return Result.success(200, "学生更新成功", studentService.updateStudent(id, student));
    }
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Result<Void> deleteStudent(@PathVariable String id) {
        studentService.deleteStudent(id);
        return Result.success(204, "学生删除成功", null);
    }
}