package com.zjsu.jyj.course.service;

import com.zjsu.jyj.course.exception.BusinessException;
import com.zjsu.jyj.course.exception.ResourceNotFoundException;
import com.zjsu.jyj.course.model.Student;
import com.zjsu.jyj.course.repository.EnrollmentRepository;
import com.zjsu.jyj.course.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StudentService {
    @Autowired
    private StudentRepository studentRepository;
    @Autowired
    private EnrollmentRepository enrollmentRepository;

    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    public Student getStudentById(String id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在（ID：" + id + "）"));
    }

    public Student getStudentByStudentId(String studentId) {
        return studentRepository.findByStudentId(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("学生不存在（学号：" + studentId + "）"));
    }

    public Student createStudent(Student student) {
        if (!studentRepository.isStudentIdUnique(student.getStudentId())) {
            throw new BusinessException("学号已存在：" + student.getStudentId());
        }
        student.setCreatedAt(LocalDateTime.now());
        return studentRepository.save(student);
    }

    public Student updateStudent(String id, Student student) {
        Student existing = getStudentById(id);
        if (!existing.getStudentId().equals(student.getStudentId())
                && !studentRepository.isStudentIdUnique(student.getStudentId())) {
            throw new BusinessException("学号已存在：" + student.getStudentId());
        }
        existing.setStudentId(student.getStudentId());
        existing.setName(student.getName());
        existing.setMajor(student.getMajor());
        existing.setGrade(student.getGrade());
        existing.setEmail(student.getEmail());
        return studentRepository.save(existing);
    }

    public void deleteStudent(String id) {
        Student student = getStudentById(id);
        if (!enrollmentRepository.findByStudentId(id).isEmpty()) {
            throw new BusinessException("无法删除：学生（" + student.getStudentId() + "）有选课记录");
        }
        studentRepository.deleteById(id);
    }
}