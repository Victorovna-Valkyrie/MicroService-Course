package com.zjsu.jyj.course.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Student {
    private String id;
    @NotBlank(message = "学号不能为空")
    private String studentId;
    @NotBlank(message = "姓名不能为空")
    private String name;
    @NotBlank(message = "专业不能为空")
    private String major;
    @Positive(message = "入学年份必须为正数")
    private Integer grade;
    @NotBlank(message = "邮箱不能为空")
    @Email(message = "邮箱格式不正确")
    private String email;
    private LocalDateTime createdAt;
}