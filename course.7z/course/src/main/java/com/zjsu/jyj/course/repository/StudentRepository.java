package com.zjsu.jyj.course.repository;

import com.zjsu.jyj.course.model.Student;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class StudentRepository {
    private final Map<String, Student> studentMap = new ConcurrentHashMap<>();
    private final Map<String, String> studentIdMap = new ConcurrentHashMap<>(); // 学号->系统ID

    public List<Student> findAll() {
        return new ArrayList<>(studentMap.values());
    }

    public Optional<Student> findById(String id) {
        return Optional.ofNullable(studentMap.get(id));
    }

    public Optional<Student> findByStudentId(String studentId) {
        String id = studentIdMap.get(studentId);
        return id != null ? findById(id) : Optional.empty();
    }

    public Student save(Student student) {
        if (student.getId() == null) {
            student.setId(UUID.randomUUID().toString());
            studentIdMap.put(student.getStudentId(), student.getId());
        } else {
            Student old = studentMap.get(student.getId());
            if (old != null && !old.getStudentId().equals(student.getStudentId())) {
                studentIdMap.remove(old.getStudentId());
                studentIdMap.put(student.getStudentId(), student.getId());
            }
        }
        studentMap.put(student.getId(), student);
        return student;
    }

    public boolean deleteById(String id) {
        Student student = studentMap.remove(id);
        if (student != null) {
            studentIdMap.remove(student.getStudentId());
            return true;
        }
        return false;
    }

    public boolean isStudentIdUnique(String studentId) {
        return !studentIdMap.containsKey(studentId);
    }
}