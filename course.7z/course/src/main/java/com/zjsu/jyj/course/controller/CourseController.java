package com.zjsu.jyj.course.controller;

import com.zjsu.jyj.course.model.Course;
import com.zjsu.jyj.course.service.CourseService;
import com.zjsu.jyj.course.util.Result;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/courses")
public class CourseController {
    @Autowired
    private CourseService courseService;

    @GetMapping
    public Result<List<Course>> getAllCourses() {
        return Result.success(courseService.getAllCourses());
    }

    @GetMapping("/{id}")
    public Result<Course> getCourseById(@PathVariable String id) {
        return Result.success(courseService.getCourseById(id));
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Result<Course> createCourse(@Valid @RequestBody Course course) {
        return Result.success(201, "课程创建成功", courseService.createCourse(course));
    }

    @PutMapping("/{id}")
    public Result<Course> updateCourse(@PathVariable String id, @Valid @RequestBody Course course) {
        return Result.success(HttpStatus.OK.value(), "课程更新成功", courseService.updateCourse(id, course));
    }


    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public Result<Void> deleteCourse(@PathVariable String id) {
        courseService.deleteCourse(id);
        return Result.success(204, "课程删除成功", null);
    }
}